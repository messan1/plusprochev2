<div class="section testimonial-section wf-section">
    <div class="wrapper horizontal-flex top-align vertical-flex-mobile">
      <div data-w-id="26c853c2-15e5-acc0-1098-1540cad6d830" style="opacity:0" class="faq-wrapper">
        <div class="container-2 w-container">
          <h3 class="heading-1 _850-width centre text-white">Avis</h3>
        </div>
        <div class="columns-16 w-row">
          <div class="w-col w-col-4">
            <div class="div-block-69"><img src={{asset("images/Group-12882x_1Group-12882x.png")}} width="41" height="51" alt="" class="image-7">
              <p class="testimonial-name"><strong>Franck Berté</strong><br></p>
            </div>
          </div>
          <div class="w-col w-col-8">
            <p class="large-testimonial">&quot;Facile d&#x27;utilisation. Bon support et &quot;</p>
          </div>
        </div>
        <div class="w-row">
          <div class="w-col w-col-4">
            <div class="div-block-69"><img src={{asset("images/Headshot2x.jpg")}} width="41" height="51" alt="" class="image-7">
              <p class="testimonial-name"><strong>Alain Pascal</strong><br></p>
            </div>
          </div>
          <div class="w-col w-col-8">
            <p class="large-testimonial">&quot;Commande et livraison rapides. Et un bon suivi&quot;</p>
          </div>
        </div>
        <div class="w-row">
          <div class="w-col w-col-4">
            <div class="div-block-69"><img src={{asset("images/Wow-moment-A2x.jpg")}} width="41" height="51" sizes="41px"  alt="" class="image-7">
              <p class="testimonial-name"><strong>Irène Méa</strong><br></p>
            </div>
          </div>
          <div class="w-col w-col-8">
            <p class="large-testimonial">&quot;Témoignage très rapide et mémorable d&#x27;un de vos clients.&quot;</p>
          </div>
        </div>
        <div class="div-block-86">
          <a href="../old/listing.html" target="_blank" class="button no-max-width call-to-action w-button">Comment ça marche</a>
          <a href="../old/listing.html" target="_blank" class="button no-max-width call-to-action w-button">Nous contacter</a>
        </div>
      </div>
    </div>
  </div>
