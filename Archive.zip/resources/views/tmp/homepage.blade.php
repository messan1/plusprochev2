
@extends("layouts.layout")

@section("content")


        <!-- Search Bar -->
        @include('includes.searchBar')

        <!-- End Search Bar -->


        <!-- Offers Bar -->
        @include('includes.recentsOffers')

        <!-- End Offers Bar -->


        <!-- Testimonials Bar -->
        @include('includes.testimonials')

        <!-- Testimonials Bar -->


@stop
